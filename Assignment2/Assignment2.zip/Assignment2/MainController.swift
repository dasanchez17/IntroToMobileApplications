//
//  ViewController.swift
//  Assignment2
//
//  Created by Daniel Sanchez on 6/29/16.
//  Copyright © 2016 Squad. All rights reserved.
//

import UIKit

class MainController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

